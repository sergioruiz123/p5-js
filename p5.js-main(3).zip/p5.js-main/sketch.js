//corre solo una vez cuando inicia el programa
function setup(){
    console.log("setup - frameCount:"+frameCount);
    
    //createCanvas: ancho, alto en píxeles
    createCanvas(800,300);

    //background RGB : Define el color del fondo
    // RED --> background(255,0,0);
    // GREEN --> background(0,255, 0);
    // BLUE --> background(0,255, 0);

}

//corre continuamente después de la función setup
function draw(){
    console.log("draw - frameCount:"+frameCount);
    
      //instrucciones a ejecutar en bucle

}
